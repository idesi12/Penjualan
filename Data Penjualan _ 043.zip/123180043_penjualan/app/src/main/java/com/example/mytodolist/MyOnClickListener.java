package com.example.mytodolist;

import android.view.View;

public interface MyOnClickListener {
    void onClickListener(View view, int itemPosition);
}
